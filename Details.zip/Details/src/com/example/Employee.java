package com.example;

public class Employee 
{  
private int id;  
private String name; 
private int age;                                            
public Employee(){}  
public Employee(int i, String string, int age2) {
 this.id=i;
 this.name=string;
 this.age=age2;
}
public void setId(int id){this.id=id;}  
public int getId(){return id;}  
public void setName(String name){this.name=name;}  
public String getName(){return name;}  
public void setAge(int age){this.age=age;}  
public int getAge(){return age;}  
public  static String toString(Employee list) {
String json="{id :"+list.getId() +"name:"+list.getName() +"age:"+list.getAge()+"}";
return json;
	
}
}

