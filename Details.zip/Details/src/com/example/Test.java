package com.example;

import java.util.ArrayList;

public class Test {
	public ArrayList<Employee> getList() {
		
	ArrayList<Employee> list = new ArrayList<Employee>();
	Employee e1 = new Employee(1,"Anil",22);//create a new object
	list.add(e1);//Adding it to the list  
	Employee e2 = new Employee(2,"Mahesh",23);//create a new object
	list.add(e2);//Adding it to the list
	
	Employee e3 = new Employee(3,"Ramesh",24);//create a new object
	list.add(e3);//Adding it to the list
	for(Employee i:list)
	{
		System.out.println(Employee.toString(i));
	}
	return list;
}
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Test obj=new Test();
	obj.getList();
		
			}
		}

		

